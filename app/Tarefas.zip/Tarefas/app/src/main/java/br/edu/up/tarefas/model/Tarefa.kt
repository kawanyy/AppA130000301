package br.edu.up.tarefas.model

class Tarefa(
    val tarefa: String? = null,
    val descricao: String? = null
) {
}